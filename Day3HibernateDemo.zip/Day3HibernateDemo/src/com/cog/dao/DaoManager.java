package com.cog.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.omg.CORBA.PRIVATE_MEMBER;

import com.cog.entities.Address;
import com.cog.entities.Manager;
import com.cog.entities.Payment;
import com.cog.entities.Person;
import com.cog.resources.HibernateUtil;

public class DaoManager {
	
	
	private SessionFactory factory;
	private Session session;
	private boolean status;
	

	public DaoManager() {
		
		factory=HibernateUtil.GetFactory();
	}
	
	public boolean AddPayment(Payment payment){
		session=factory.openSession();
		session.beginTransaction();
		
		try {
			session.save(payment);
			session.getTransaction().commit();
			status=true;
		} catch (HibernateException e) {
			
			session.getTransaction().rollback();
		}
		
		session.close();
		return status;
		
		
		
	}
	
	public boolean AddPerson(Person person,Address address){
		session=factory.openSession();
		session.beginTransaction();
		
		try {
			session.persist(address);
			person.setAddress(address);
			session.persist(person);
			session.getTransaction().commit();
			
			status=true;
		} catch (HibernateException e) {
			
			session.getTransaction().rollback();
		}
		
		session.close();
		return status;
		
		
		
	}
	
	public List<Manager> GetAll(){
		session=factory.openSession();
		session.beginTransaction();
		
		
		return session.createQuery("from Manager").list();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
