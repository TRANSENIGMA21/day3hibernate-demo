package com.cog.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="CTS_Employee")
/*@PrimaryKeyJoinColumn(name="Aadhar_Id", referencedColumnName="AadharCardNo")*/
public class Employee extends Person {
	
	
	@Column(name="Employee_No")
	private int employeeNo; 
	@Column(name="Project")
	private String project;
	@Column(name="Location")
	private String location;
	public int getEmployeeNo() {
		return employeeNo;
	}
	public void setEmployeeNo(int employeeNo) {
		this.employeeNo = employeeNo;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	
	

}
