package com.cog.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="CTS_Manager")

public class Manager extends Employee {
	@Column(name="No_Of_Project")
	private int noOfProject;
	@Column(name="LeaveApproval")
	private boolean leaveApproval;
	public int getNoOfProject() {
		return noOfProject;
	}
	public void setNoOfProject(int noOfProject) {
		this.noOfProject = noOfProject;
	}
	public boolean isLeaveApproval() {
		return leaveApproval;
	}
	public void setLeaveApproval(boolean leaveApproval) {
		this.leaveApproval = leaveApproval;
	}
	
	
	
	
	
	
	
	
	
	
	

}
