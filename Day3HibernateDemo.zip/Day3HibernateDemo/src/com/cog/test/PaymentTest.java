package com.cog.test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cog.dao.DaoManager;
import com.cog.entities.Address;
import com.cog.entities.CreditCard;
import com.cog.entities.Payment;

public class PaymentTest {
	private DaoManager dao;

	@Before
	public void setUp() throws Exception {
		
		 dao=new DaoManager();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void PaymentObjtest() {
		//fail("Not yet implemented");
		
		Payment payment=new Payment();
		payment.setAmount(10000);
		payment.setDOT(new Date(16,5,5));
		assertTrue(dao.AddPayment(payment));
		
	}
	
	@Test
	public void CreditCardObjtest() {
		//fail("Not yet implemented");
		
		CreditCard payment=new CreditCard();
		payment.setCustomerId(527);
		payment.setAmount(10000);
		payment.setDOT(new Date(16,5,5));
		payment.setCreditcardNO(52896);
		payment.setcName("ajay");
		payment.setcExpiryDate(new Date(25,26,31));
		payment.setcEMI(false);
		payment.setCvv(452);
		
		assertTrue(dao.AddPayment(payment));
		
	}
	
	


}
