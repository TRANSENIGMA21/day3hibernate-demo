package com.cog.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cog.dao.DaoManager;
import com.cog.entities.Address;
import com.cog.entities.Manager;
import com.cog.entities.Person;

public class PersonTest {
	
	private DaoManager dao;

	@Before
	public void setUp() throws Exception {
		
		dao=new DaoManager();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		//fail("Not yet implemented");
		for(Manager manager:dao.GetAll()){
			System.out.println(manager.getAadharCardNo()+"\t");
			System.out.println(manager.getName()+"\t");
			System.out.println(manager.getAddress().getStreetname()+"\t");
			System.out.println(manager.getAddress().getCity()+"\t");
			System.out.println(manager.getAddress().getState()+"\t");
			System.out.println(manager.getEmployeeNo()+"\t");
			System.out.println(manager.getAadharCardNo()+"\t");
			
			System.out.println(manager.getAadharCardNo()+"\t");
			System.out.println(manager.getAadharCardNo()+"\t");
			System.out.println(manager.getAadharCardNo()+"\t");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*Manager person = new Manager();
		person.setName("mukesh");
		person.setEmployeeNo(562589);
		person.setLeaveApproval(true);
		person.setAadharCardNo(15426987);
		person.setNoOfProject(25);
		person.setProject("Hsbc");
		Address address= new Address();
		address.setCity("banglore");
		address.setState("karnataka");
		address.setStreetname("GM Road");

		assertTrue(dao.AddPerson(person, address));
		*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*Person person = new Person();
		person.setName("Ajay");
		Address address=new Address();
		address.setStreetname("Gandhi Street");
		address.setCity("chennai");
		address.setState("TN");
		assertTrue(dao.AddPerson(person, address));
		*/
	}

}
